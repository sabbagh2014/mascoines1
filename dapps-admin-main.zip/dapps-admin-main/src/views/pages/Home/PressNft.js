import React from 'react';

export default function PressNft() {
  return <div><p>hhhh</p></div>;
}
