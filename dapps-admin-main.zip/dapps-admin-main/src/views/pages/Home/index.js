import React from "react";
import { Box } from "@material-ui/core";
import { Button } from "@material-ui/core";
import Page from "src/component/Page";
function Bids(props) {
  return (
    <Page title="Marketplace | Fungy">
      <Box>
        {/* <CollectionStory />
        <User />
        <BestSeller />
        <HotBids />
        <LatestArtwork />
        <Explore /> */}
      </Box>
    </Page>
  );
}

export default Bids;
