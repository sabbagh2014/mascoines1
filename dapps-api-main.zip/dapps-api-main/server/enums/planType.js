module.exports = Object.freeze({
  BASIC: "Basic",
  SILVER: "Silver",
  GOLD: "Gold",
  DIAMOND: "Diamond",
  MASS_PLUS: "Mass Plus",
});
