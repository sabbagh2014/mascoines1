module.exports = Object.freeze({
  ADMIN: "Admin",
  USER: "User",
  SUB_ADMIN: "Subadmin",
  CREATOR: "Creator",
});
